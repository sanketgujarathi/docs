package com.modulrfinance.technicaltest.atm;

import com.modulrfinance.technicaltest.account.AccountService;
import com.modulrfinance.technicaltest.money.Denomination;
import com.modulrfinance.technicaltest.money.MoneyAsNotes;

import java.math.BigDecimal;

class ATMService {

    private AccountService accountService;
    private MoneyAsNotes vault;

    ATMService(AccountService accountService, MoneyAsNotes vault) {
        this.accountService = accountService;
        this.vault = vault;
    }

    String checkBalance(String accountNumber) {
        BigDecimal balance = accountService.checkBalance(accountNumber);
        return balance.toString();
    }

    void replenish(MoneyAsNotes moneyAsNotes) {
        vault = vault.add(moneyAsNotes);
    }

    MoneyAsNotes withdraw(String accountNumber, BigDecimal amount) {
        MoneyAsNotes withdrawalPool = prepareMoney(amount);
        accountService.withdraw(accountNumber, amount);
        vault = vault.remove(withdrawalPool);
        return withdrawalPool;
    }

    private MoneyAsNotes prepareMoney(BigDecimal amount) {
        MoneyAsNotes moneyAsNotes = prepareMoneyStep(amount, vault);
        if (moneyAsNotes == null) {
            throw new NotEnoughNotesException();
        }
        return moneyAsNotes;
    }

    private MoneyAsNotes prepareMoneyStep(BigDecimal amount, MoneyAsNotes remainingVault) {
        if (amount.compareTo(BigDecimal.ZERO) == 0) {
            return MoneyAsNotes.createEmpty();
        }
        if (amount.compareTo(BigDecimal.ZERO) < 0) {
            return null;
        }
        for (Denomination denomination : Denomination.valuesDescending()) {
            if (remainingVault.get(denomination) > 0) {
                BigDecimal remainingAmount = amount.subtract(denomination.value());
                MoneyAsNotes moneyAsNotes = prepareMoneyStep(remainingAmount, remainingVault.remove(denomination, 1));
                if (moneyAsNotes != null) {
                    return moneyAsNotes.add(denomination, 1);
                }
            }
        }
        return null;
    }
}
